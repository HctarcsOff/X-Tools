minetest.register_craft({
        type = "shaped",
	output = "x_tools:sword",
	recipe = {
        {"", "x_tools:mineral",  ""},
        {"", "x_tools:mineral",  ""},
        {"", "default:stick",   ""}
	}
})

minetest.register_craft({
    type = "cooking",
    output = "x_tools:mineral",
    recipe = "x_tools:mineral_lump",
    cooktime = 10,
})

minetest.register_craft({
        type = "shaped",
	output = "x_tools:axe",
	recipe = {
        {"x_tools:mineral", "x_tools:mineral",  ""},
        {"x_tools:mineral", "default:stick",  ""},
        {"", "default:stick",   ""}
	}
})

minetest.register_craft({
        type = "shaped",
	output = "x_tools:pick",
	recipe = {
        {"x_tools:mineral", "x_tools:mineral",  "x_tools:mineral"},
        {"", "default:stick",  ""},
        {"", "default:stick",   ""}
	}
})

minetest.register_craft({
        type = "shaped",
	output = "x_tools:shovel",
	recipe = {
        {"", "x_tools:mineral",  ""},
        {"", "default:stick",  ""},
        {"", "default:stick",   ""}
	}
})

minetest.register_craft({
        type = "shaped",
	output = "x_tools:hoe",
	recipe = {
        {"x_tools:mineral", "x_tools:mineral",  ""},
        {"", "default:stick",  ""},
        {"", "default:stick",   ""}
	}
})

minetest.register_craft({
        type = "shaped",
	output = "x_tools:block",
	recipe = {
        {"x_tools:mineral", "x_tools:mineral",  "x_tools:mineral"},
        {"x_tools:mineral", "x_tools:mineral",  "x_tools:mineral"},
        {"x_tools:mineral", "x_tools:mineral",   "x_tools:mineral"}
	}
})

minetest.register_craft({
        type = "shaped",
	output = "x_tools:block_smoth",
	recipe = {
        {"x_tools:block", "x_tools:block",  "x_tools:block"},
        {"x_tools:block", "x_tools:block",  "x_tools:block"},
        {"x_tools:block", "x_tools:block",   "x_tools:block"}
	}
})