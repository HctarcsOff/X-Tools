minetest.register_tool("x_tools:sword", {
	description = ("X Sword"),
	inventory_image ="x_tools_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.25,
		max_drop_level=0,
		groupcaps={
		   crumbly = {
                     maxlevel = 10,
                     uses = 50000,
                     times = { [1]=1.60, [2]=1.20, [3]=0.80 }
		  },
        },
        damage_groups = {fleshy=10},
    },
})

minetest.register_tool("x_tools:pick", {
	description = ("X Sword"),
	inventory_image ="x_tools_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=0,
		groupcaps={
		   crumbly = {
                     maxlevel = 10,
                     uses = 50000,
                     times = { [1]=1.60, [2]=1.20, [3]=0.80 }
		  },
        },
        damage_groups = {cracky=10},
    },
})

minetest.register_tool("x_tools:axe", {
	description = ("X Axe"),
	inventory_image ="x_tools_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=0,
		groupcaps={
		   crumbly = {
                     maxlevel = 10,
                     uses = 50000,
                     times = { [1]=1.60, [2]=1.20, [3]=0.80 }
		  },
        },
        damage_groups = {choppy=10},
    },
})

minetest.register_tool("x_tools:shovel", {
	description = ("X Shovel"),
	inventory_image ="x_tools_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=0,
		groupcaps={
		   crumbly = {
                     maxlevel = 10,
                     uses = 50000,
                     times = { [1]=1.60, [2]=1.20, [3]=0.80 }
		  },
        },
        damage_groups = {crumbly=10},
    },
})

minetest.register_tool("x_tools:hoe", {
	description = ("X Hoe"),
	inventory_image ="x_tools_hoe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=0,
		groupcaps={
		   crumbly = {
                     maxlevel = 10,
                     uses = 50000,
                     times = { [1]=1.60, [2]=1.20, [3]=0.80 }
		  },
        },
    },
})


