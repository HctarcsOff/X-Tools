minetest.register_craftitem("x_tools:mineral_lump", {
    description = "X Mineral Lump",
    inventory_image = "x_tools_mineral_lump.png"
})

minetest.register_craftitem("x_tools:mineral", {
    description = "X Mineral",
    inventory_image = "x_tools_mineral.png"
})