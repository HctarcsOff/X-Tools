minetest.register_alias("acrk_sword", "x_swords:arck_sword")

