print("This file will be run at load time!")

minetest.register_node("x_tools:ore", {
    description = "X Ore",
    tiles = {
        "x_tools_ore.png",    -- y+
        "x_tools_ore.png",  -- y-
        "x_tools_ore.png", -- x+
        "x_tools_ore.png",  -- x-
        "x_tools_ore.png",  -- z+
        "x_tools_ore.png", -- z-
    },
    is_ground_content = true,
    groups = {cracky = 3},
    drop = "x_tools:mineral_lump"
})

minetest.register_node("x_tools:block", {
    description = "X Block",
    tiles = {
        "x_tools_mineral_block.png",    -- y+
        "x_tools_mineral_block.png",  -- y-
        "x_tools_mineral_block.png", -- x+
        "x_tools_mineral_block.png",  -- x-
        "x_tools_mineral_block.png",  -- z+
        "x_tools_mineral_block.png", -- z-
    },
    is_ground_content = false,
    groups = {cracky = 3},
    drop = "x_tools:block"
})

minetest.register_node("x_tools:ore", {
    description = "X Smoth Block",
    tiles = {
        "x_tools_mineral_block_smoth.png",    -- y+
        "x_tools_mineral_block_smoth.png",  -- y-
        "x_tools_mineral_block_smoth.png", -- x+
        "x_tools_mineral_block_smoth.png",  -- x-
        "x_tools_mineral_block_smoth.png",  -- z+
        "x_tools_mineral_block_smoth.png", -- z-
    },
    is_ground_content = false,
    groups = {cracky = 3},
    drop = "x_tools:block_smoth"
})

dofile(minetest.get_modpath("x_tools") .. "/crafting.lua")
dofile(minetest.get_modpath("x_tools") .. "/tools.lua")
dofile(minetest.get_modpath("x_tools") .. "/items.lua")
